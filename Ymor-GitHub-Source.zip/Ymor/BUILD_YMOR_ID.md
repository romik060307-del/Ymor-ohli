# Cara build APK Ymor di GitHub

1. Buat repository baru di GitHub.
2. Upload semua isi folder proyek Ymor (bukan file ZIP-nya).
3. Buka tab **Actions**. Jika GitHub meminta aktivasi Actions, pilih izinkan.
4. Pilih workflow **Build Ymor APK**.
5. Tekan **Run workflow**, lalu jalankan pada branch utama.
6. Setelah status hijau, buka hasil run dan unduh artifact **Ymor-Android-APK**.
7. Ekstrak ZIP artifact, lalu pasang file `Ymor.apk` di HP.

Build awal menghasilkan APK debug yang sudah ditandatangani untuk pengujian. Untuk distribusi dan update jangka panjang, siapkan satu keystore milik sendiri lalu simpan nilainya sebagai GitHub Actions Secrets sebelum membuat build release.
