# Ymor static security review

This is a source-level review of the supplied project snapshot, not a full antivirus certification or a dynamic penetration test.

## Ymor build defaults

- The Android app ID is `app.ymor.music`.
- The in-app updater is disabled (`UPDATER_ENABLED=false`).
- `REQUEST_INSTALL_PACKAGES` was removed from the main Android manifest because Ymor does not self-install updates.
- Android Sentry plugin/runtime integration and release-only upload adapters were removed. All Android variants use local no-op crash-reporting adapters; no crash-reporting endpoint is configured in the Android build.
- The app version string carries build metadata so the shared crash-reporting availability check is also disabled.
- No camera, contacts, SMS, location, or overlay permission is declared in the supplied main Android manifest.
- Microphone access remains for the optional music-recognition feature; it is not needed for ordinary playback.
- Internet, Wi-Fi/local-network, Bluetooth, notification, media-service, and legacy external-storage permissions support streaming, casting, Bluetooth controls, background playback, notifications, and saving media on older Android versions.

## Limits

A static source review cannot prove that every external dependency or upstream service is harmless. The app still connects to YouTube Music and other configured providers for playback, lyrics, imports, casting, and optional integrations. Build from the source in this repository and review dependency changes before distributing updated binaries.
